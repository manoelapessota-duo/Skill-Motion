---
name: motion
description: Cria vídeos de motion design em Remotion a partir de um pedido em português - tipografia cinética com a palavra aparecendo quando é dita, mira de laser, faísca de luz, grade em perspectiva, partículas, HUD e 20 transições prontas (glitch, chicote, túnel, estilhaço, película, flood...). Use quando o usuário pedir "faz um motion", animação de texto, vinheta, abertura, intro, reel ou anúncio animado, tipografia cinética, legenda animada sincronizada com narração, ou quiser editar, ajustar ou renderizar as cenas e transições do projeto modelo da Skill Motion.
---

# Skill Motion

Você vai escrever a animação como código (Remotion + React) a partir de um projeto modelo que já tem
as 19 cenas de um filme de motion, os blocos que montam cada cena e 20 transições. O que faz o
resultado ficar bom são as referências: **leia antes de animar**.

## 0. Antes de tudo

1. Leia `references/guia-motion.md` inteiro (tipografia, grade, ritmo, easing, paleta, a regra da fala
   sincronizada e o checklist). Os valores de lá são o padrão de qualquer pedido.
2. Leia `references/catalogo.md` para saber quais cenas, blocos e transições já existem. Reaproveite
   antes de criar do zero.
3. Se houver fala ou texto falado, leia `references/tempos.md`.

O projeto modelo está na pasta `projeto/` ao lado deste SKILL.md (a "pasta desta skill" é a que o
Claude Code mostra como base directory ao carregar a skill). Se não estiver lá, pergunte ao usuário
onde ele descompactou a pasta `skill-motion` e use a `projeto/` de lá.

## 1. Pasta de trabalho

Se o usuário não disse onde trabalhar, crie `./motion/` no diretório atual. Se a pasta já tiver um
`package.json` deste projeto, reaproveite (pule a cópia e o `npm install`).

Copie o modelo (sem `node_modules`, se existir) e instale:

```bash
# Mac / Linux
mkdir -p motion && cp -R "<pasta desta skill>/projeto/." motion/ && rm -rf motion/node_modules
cd motion && npm install
```

```powershell
# Windows (PowerShell)
New-Item -ItemType Directory -Force motion | Out-Null
Copy-Item -Recurse -Force "<pasta desta skill>\projeto\*" .\motion\
cd motion ; npm install
```

Precisa de Node 18 ou mais novo. O primeiro render baixa um navegador headless (~90 MB) sozinho.

## 2. Planejar (em uma resposta curta, sem pedir aprovação para pedido simples)

- Texto: o que é dito/escrito. Uma frase por cena. Palavra-chave de cada frase.
- Duração: se o usuário deu (ex.: "8 segundos"), respeite; senão, o texto dita (~3 palavras/s).
- Para cada cena: o elemento principal (palavra gigante, mira, faísca, cartões...) e a transição de
  entrada (uma diferente em cada corte; ver a tabela do guia). Se o usuário pediu uma transição ou um
  bloco pelo nome ("mira de laser", "glitch"), use exatamente esse.

## 3. Tempos

- Sem narração: `node scripts/tempos-de-texto.mjs "frase 1 | frase 2 | frase 3" > src/videos/<nome>/tempos.json`
  e ajuste `--ritmo` para bater a duração pedida.
- Com narração: áudio em `public/`, `scripts/transcrever.mjs` (ver `references/tempos.md`), corrija a
  grafia, passe `audio="arquivo.mp3"` no `<VideoMontado>`.

## 4. Construir

1. Copie `src/videos/demo/` para `src/videos/<nome>/` (Demo.tsx → `<Nome>.tsx`). A demo é o modelo:
   cenas como componentes que usam `useCenaM()`, a fala por `T.falaDaCena(n)` + `<Fala>`, e
   `montarRoteiro({ cenasFala: T.CENAS_FALA, entradas: [null, entrada('glitchRGB'), ...], duracao })`.
2. Monte cada cena com os blocos (`import { ... } from '../../blocos'`): fundo (`FundoM`, `GradeChao`,
   `Poeira`), câmera viva (`Camera`), fala (`Fala`), luz (`Faisca`, `LinhaLuz`, `Flare`), `MiraLaser`,
   impacto (`Onda`, `Fagulhas`), `HUD`. Para algo que já existe no filme, abra a cena `src/cenas/mNN-*.tsx`
   e copie o trecho.
3. Prenda todo evento a uma palavra: `const q = c.local(fala[i].s)` (nunca número fixo de quadro).
4. Siga o guia: easing nunca linear em coisa visível, nada parado mais de 0,5 s, texto com 28 px ou
   mais, um acento só (a `PALETA` do `src/tema.ts`), vermelho só para riscar.
5. Registre a composição no `src/Root.tsx` (id em PascalCase ou com hífen, ex.: `Foco-8s`).
6. Formato: 1920x1080 por padrão. Vertical (Reels/TikTok) = 1080x1920: mesma tipografia, posições
   refeitas para a tela alta (texto no terço central, margem lateral de 80 a 100 px).

## 5. Conferir (obrigatório antes do render)

```bash
npx tsc --noEmit
node scripts/stills.mjs <Composicao> out/stills 0.5 <q1> <q2> <q3> ...
```

Escolha quadros no meio de cada cena, no pico de cada transição e 2 quadros depois de uma palavra-chave.
Abra as imagens (Read) e passe o checklist da seção 9 do guia. Corrija e repita até passar.

## 6. Renderizar

```bash
npx remotion render src/index.ts <Composicao> out/<nome>.mp4
```

Em máquina com pouca memória, some `--concurrency=2`. Para prévia rápida, `--scale=0.5`. Entregue o
caminho do MP4 e diga em uma linha o que tem em cada cena.

## 7. Ajustes por conversa

O usuário vai pedir em português. Traduza para código, mude só o que foi pedido e renderize de novo:

| Pedido | Onde mexer |
|---|---|
| "mais suave" / "mais rápido" na transição | `T` e `k` da entrada, ou a curva (`corte` → `suave`) |
| "muda a cor" / "deixa azul" | `PALETA` em `src/tema.ts` (`acento`, `acentoClaro`, `halo`) |
| "desacelera aqui" | `--ritmo` dos tempos, ou segure a palavra no `tempos.json` |
| "palavra maior" / "mais impacto" | `estilo` (`TIPOM.gigante`), `modo="slam"`, `Onda` + `Fagulhas` na palavra |
| "o final volta pro começo" | último quadro igual ao primeiro (ver o loop da cena 19 → cena 1) |
| "troca a transição" | `entrada('<outra>')` na lista do roteiro |
| "vertical" | composição 1080x1920 e posições refeitas |

## 8. Editar o filme modelo

`Filme-16x9` (inteiro) e `M-01` ... `M-19` (cenas isoladas) já estão registrados; os tempos de exemplo
estão em `src/filme/tempos.json` (sem áudio). Para ver tudo no navegador: `npm run studio`.

## Regras

- Nunca use logo de terceiro nem fonte fora de `public/fonts/`: `<LogoApp>` é o lugar reservado.
- Não apague as cenas, blocos ou transições do modelo; crie o vídeo novo em `src/videos/<nome>/`.
- Remotion tem licença própria: grátis para pessoa física, organização sem fins lucrativos e empresa
  de até 3 pessoas; acima disso a empresa precisa da licença deles (remotion.dev/license).
