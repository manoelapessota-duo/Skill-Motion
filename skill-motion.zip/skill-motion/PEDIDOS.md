# 5 pedidos prontos

Abra o terminal na pasta onde quer o vídeo, rode `claude` e cole um destes pedidos. Troque o que está
entre colchetes. O vídeo sai em `motion/out/`.

---

## 1. Palavra com mira de laser (8 s, 16:9)

```
Faz um motion de 8 segundos apresentando a palavra [FOCO]. Uma mira de laser varre a tela e trava
na palavra, que entra gigante e incandescente. Antes dela, a frase "[o que separa quem termina de
quem desiste]" aparece palavra por palavra. Usa uma transição de glitch entre as duas partes.
```

## 2. Vinheta de abertura (6 s, 16:9)

```
Cria uma vinheta de abertura de 6 segundos para o canal [NOME DO CANAL]. Uma faísca de luz escreve
o nome em letra fina sobre a grade em perspectiva, a linha de luz corre por baixo, e no fim a tela
inteira vira [verde] com a transição flood e aparece "[episódio 01]". HUD discreto nos cantos.
```

## 3. Reel vertical de lista (15 s, 9:16)

```
Faz um reel vertical 1080x1920 de 15 segundos com o texto: "[3 erros que travam sua página de
vendas] | [Erro 1: título que descreve em vez de prometer] | [Erro 2: botão escondido] | [Erro 3:
prova que ninguém confere]". Uma frase por cena, palavra-chave de cada frase em destaque, uma
transição diferente em cada corte (chicote, estilhaço, túnel). Texto grande, legível no celular.
```

## 4. Fala sincronizada com a minha narração

```
Coloquei o áudio [narracao.mp3] na pasta motion/public. Faz um motion 16:9 em que cada palavra
aparece na tela no instante em que é dita, uma frase por cena, palavra-chave de cada frase em
destaque, partículas e grade em perspectiva no fundo, e uma transição diferente em cada corte.
Antes de renderizar, me mostra 3 imagens para eu aprovar.
```

## 5. Reaproveitar uma cena do filme com a minha paleta

```
Usa a cena 9 do filme modelo (os cinco cartões com mini demonstração) para apresentar os 5 módulos
do meu curso: [módulo 1, módulo 2, módulo 3, módulo 4, módulo 5]. Troca a paleta para [azul
#3B82F6] com fundo quase preto, mantém o ritmo e o easing do guia, e fecha com a transição de
faixas mostrando o nome do curso "[NOME]". 16:9, uns 8 segundos.
```

---

Depois do primeiro vídeo, ajuste conversando: *"deixa essa transição mais suave"*, *"muda a cor"*,
*"desacelera aqui"*, *"faz o final voltar pro começo"*, *"aumenta a palavra"*, *"faz a versão vertical"*.
