# Skill Motion

Motion design com o Claude Code, sem abrir o After Effects. Você pede em português e o Claude escreve
a animação como código (Remotion) seguindo as referências desta skill, confere e entrega o MP4.

## O que tem nesta pasta

| Pasta / arquivo | O que é |
|---|---|
| `skill/` | a skill do Claude Code: `SKILL.md` (o passo a passo que o Claude segue) e `references/` (o guia de tipografia, grade, ritmo, easing e paleta, com os valores exatos, e a regra da fala sincronizada) |
| `projeto/` | o projeto Remotion pronto: as 19 cenas do vídeo como modelos editáveis, os blocos (palavra cinética sincronizada, mira de laser, faísca de luz, grade em perspectiva, partículas, HUD), 20 transições isoladas, uma demonstração curta e o filme inteiro |
| `PEDIDOS.md` | 5 pedidos prontos para copiar e colar |
| `LEIA-ME.md` | este arquivo |

## Do que você precisa

- **Claude Code** funcionando no terminal (com a sua conta). Não funciona no Claude do navegador
  nem do celular: é o Claude Code que monta e renderiza o vídeo no seu computador.
- **Node.js 18 ou mais novo** (gratuito: nodejs.org). Para conferir, rode `node -v` no terminal.
- Uns 600 MB livres em disco para o projeto (dependências + o navegador que o Remotion usa para
  renderizar, baixado sozinho no primeiro render).

## Instalar (uma vez)

Descompacte o arquivo, abra o terminal **dentro da pasta `skill-motion`** e rode o comando do seu
sistema. Ele copia a skill e o projeto modelo para a pasta de skills do Claude Code.

**Mac ou Linux** (Terminal):

```bash
mkdir -p ~/.claude/skills/motion && cp -R skill/. ~/.claude/skills/motion/ && cp -R projeto ~/.claude/skills/motion/
```

**Windows** (PowerShell):

```powershell
$d = "$env:USERPROFILE\.claude\skills\motion"; New-Item -ItemType Directory -Force $d | Out-Null; Copy-Item -Recurse -Force skill\* $d; Copy-Item -Recurse -Force projeto $d
```

Depois, abra o Claude Code de novo. Para conferir, digite `/skills` (ou pergunte "quais skills você
tem?"): a skill **motion** deve aparecer.

Para atualizar uma versão nova: apague a pasta `~/.claude/skills/motion` (no Windows,
`%USERPROFILE%\.claude\skills\motion`) e rode o comando de novo.

## Como pedir

Abra o terminal na pasta onde quer o vídeo, rode `claude` e peça em português, dizendo:

1. **O que aparece ou é dito** (a frase, a palavra, a lista).
2. **Quanto tempo** e **formato** (16:9 para YouTube/tela, vertical 9:16 para Reels/TikTok).
3. **Um ou dois elementos** que você quer ver: mira de laser, faísca escrevendo, grade em
   perspectiva, partículas, HUD, palavra gigante incandescente.
4. **A transição**, se quiser uma específica: glitch, chicote, túnel, estilhaço, película, flood,
   foco, dispersão de partículas...

Exemplo: *"faz um motion de 8 segundos apresentando a palavra FOCO com a mira de laser e uma
transição de glitch"*. O Claude cria a pasta `motion/`, instala o projeto, monta as cenas, confere em
imagens e entrega o MP4 em `motion/out/`.

Depois, ajuste conversando: *"deixa a transição mais suave"*, *"muda a cor para azul"*,
*"desacelera o começo"*, *"faz o final voltar pro começo"*. Ele muda só aquilo e renderiza de novo.

Tem narração? Ponha o áudio na pasta `motion/public/` e diga: *"usa o narracao.mp3 e faz cada
palavra aparecer quando é dita"*. (A transcrição roda no seu computador com o whisper.cpp; na
primeira vez ele baixa o programa e o modelo, algumas centenas de MB.)

Os 5 pedidos do `PEDIDOS.md` são um bom começo.

## Ver o projeto modelo sem pedir nada

```bash
cd ~/.claude/skills/motion/projeto   # ou copie a pasta para outro lugar antes
npm install
npm run studio
```

Abre o Remotion Studio no navegador com:

- **Demo**: demonstração de ~9,5 s (fala sincronizada, faísca, mira de laser, glitch, chicote).
- **filme / Filme-16x9**: o filme inteiro (19 cenas) e cada cena isolada (`M-01` a `M-19`). Vem
  **sem a narração**: as palavras seguem os tempos de exemplo em `src/filme/tempos.json`.
- **transicoes / T-…**: cada uma das 20 transições, isolada entre uma cena A e uma cena B.

Renderizar a demo direto pelo terminal:

```bash
npx remotion render src/index.ts Demo out/demo.mp4
```

## O que esta skill faz e não faz

- Serve para: texto, forma, HUD e reel; vinheta, abertura, anúncio animado, tipografia cinética,
  legenda animada sincronizada com narração.
- Não serve para: substituir uma edição completa de vídeo; substituir o After Effects aplicado em
  filmagem (rotoscopia, tracking, composição sobre vídeo gravado).
- Os ícones de aplicativo nas cenas são um lugar reservado (`LogoApp`). Só use logo que você tem
  direito de usar.

## Licenças

- **Remotion**: tem licença própria. É grátis para pessoa física, organização sem fins lucrativos e
  empresa de até 3 funcionários; acima disso, a empresa precisa comprar a licença deles
  (remotion.dev/license).
- **Fontes**: Inter e JetBrains Mono, licença SIL Open Font License (arquivos de licença em
  `projeto/public/fonts/`).
- **Claude Code**: usa a sua conta.

## Se der erro

- `node: command not found` ou versão abaixo de 18: instale o Node pelo nodejs.org.
- A skill não aparece: confira se existe `~/.claude/skills/motion/SKILL.md` e reabra o Claude Code.
- Render lento ou travando por memória: peça ao Claude para renderizar com `--concurrency=2`, ou uma
  prévia em `--scale=0.5`.
- Qualquer outro erro: cole a mensagem no Claude Code e peça para ele resolver.
